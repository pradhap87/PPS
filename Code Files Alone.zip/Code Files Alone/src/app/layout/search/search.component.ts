import { Component, OnInit } from '@angular/core';
import { Options, LabelType } from 'ng5-slider';
import sampleData from '../../../assets/PricePiggyRecommedation.json';
import { FormGroup, FormBuilder, ReactiveFormsModule, FormArray, FormControl } from '@angular/forms';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  AcRecommedation: any = sampleData;

  myForm: FormGroup; // Brand name form
  public isCollapsed = true;
  CapacityForm: FormGroup; // Capacity form
  public isCapacityCollapsed = true;


  minValue = 100;
  maxValue = 400;
  options: Options = {
    floor: 0,
    ceil: 500,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return 'Min : ₹' + value;
        case LabelType.High:
          return 'Max : ₹' + value;
        default:
          return null;
      }
    }
  };


  constructor(private fb: FormBuilder, private fbCapacity: FormBuilder) { }
  submit() {
/*     const selectedOrderIds = this.AcRecommedation
    .filter(opt => opt.checked)
    .map(opt => opt.value);
    console.log(event.checked);

  this.test = event.checked;*/
  }
  ngOnInit() {
    this.myForm = this.fb.group({
      brandname: this.fb.array([])
    });

    this.CapacityForm = this.fbCapacity.group({
      brandname: this.fbCapacity.array([])
    });

  }
  onChange(brands: string, isChecked: boolean) {
    const brandnameFormArray = <FormArray>this.myForm.controls.brandname;

    if (isChecked) {
      brandnameFormArray.push(new FormControl(brands));
    } else {
      const index = brandnameFormArray.controls.findIndex(x => x.value === brands);
      brandnameFormArray.removeAt(index);
    }
  }

  onChangeCapacity(capacity: string, isChecked: boolean) {
    const brandnameFormArray = <FormArray>this.CapacityForm.controls.brandname;

    if (isChecked) {
      brandnameFormArray.push(new FormControl(capacity));
    } else {
      const index = brandnameFormArray.controls.findIndex(x => x.value === capacity);
      brandnameFormArray.removeAt(index);
    }
  }

}
