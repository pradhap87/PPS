import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SearchComponentRoutingModule } from './search-routing.module';
import { SearchComponent } from './search.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { Ng5SliderModule } from 'ng5-slider';

@NgModule({
    imports: [CommonModule, SearchComponentRoutingModule, NgbModule, Ng5SliderModule, FormsModule, ReactiveFormsModule],
    declarations: [SearchComponent]
})
export class SearchModule {}
