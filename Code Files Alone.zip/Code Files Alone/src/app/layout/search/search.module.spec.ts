import { Search.Module } from './search.module';

describe('Search.Module', () => {
  it('should create an instance', () => {
    expect(new Search.Module()).toBeTruthy();
  });
});
