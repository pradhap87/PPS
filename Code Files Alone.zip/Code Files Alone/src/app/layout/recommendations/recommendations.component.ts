import { Component, OnInit } from '@angular/core';
import sampleData from '../../../../src/assets/PricePiggyRecommedation.json';

@Component({
  selector: 'app-recommendations',
  templateUrl: './recommendations.component.html',
  styleUrls: ['./recommendations.component.scss']
})
export class RecommendationsComponent implements OnInit {
  AcRecommedation: any = sampleData;
  constructor() { }

  ngOnInit() {
  }

}
