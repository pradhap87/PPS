import { Component, OnInit } from '@angular/core';
import sampleData from '../../../../../assets/PricePiggyRecommedation.json';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {
  AcRecommedation: any = sampleData;
  constructor() { }

  ngOnInit() {
  }

}
