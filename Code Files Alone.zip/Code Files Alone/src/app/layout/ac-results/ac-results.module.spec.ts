import { AcResultsModule } from './ac-results.module';

describe('AcResults.Module', () => {
  it('should create an instance', () => {
    expect(new AcResultsModule()).toBeTruthy();
  });
});
