import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AcResultsRoutingModule } from './ac-results-routing.module';
import { ACResultsComponent } from './ac-results.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    imports: [CommonModule, AcResultsRoutingModule, NgbModule],
    declarations: [ACResultsComponent]
})
export class AcResultsModule {}
