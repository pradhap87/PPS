import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ACResultsComponent } from './ac-results.component';

describe('ACResultsComponent', () => {
  let component: ACResultsComponent;
  let fixture: ComponentFixture<ACResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ACResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ACResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
