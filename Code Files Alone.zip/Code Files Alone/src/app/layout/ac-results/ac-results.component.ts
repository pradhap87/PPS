import { Component, OnInit } from '@angular/core';
import sampleData from '../../../assets/PricePiggyRecommedation.json';
import { ApiService } from '../../shared/services/api.service';

@Component({
  selector: 'app-ac-results',
  templateUrl: './ac-results.component.html',
  styleUrls: ['./ac-results.component.scss']
})
export class ACResultsComponent implements OnInit {
  WebApi: any;
  AcRecommedation: any = sampleData;
  currentRate = 7.5;
  constructor(private acApiService: ApiService) { }

  ngOnInit() {
    this.acApiService.getACData().subscribe((data) => {
      console.log(data);
    });
  }

}
