import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ACResultsComponent } from './ac-results.component';

const routes: Routes = [
    {
        path: '',
        component: ACResultsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class AcResultsRoutingModule {
}
