import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
   constructor(private httpClient: HttpClient) { }
// https://cors-anywhere.herokuapp.com/ -- add this for CROS issue.
   public getACData() {
    return this.httpClient.get(`https://cors-anywhere.herokuapp.com/https://v3xdr8w1eh.execute-api.us-west-2.amazonaws.com/Prod/api/Buyer`);
  }
}
